const { prepareWAMessageMedia, generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");
const config = require('./config.js');
const fs = require('fs');
const util = require('util');
const Jimp = require('jimp');
const axios = require("axios");
const cheerio = require('cheerio');
const QRCode = require("qrcode");
const OpenAI = require("openai");
const yts = require("yt-search");
const { Client } = require('ssh2');
const path = './database/done_transactions.json';
const { exec } = require("child_process");
const { isOwner } = require('./config');
const fetch = require('node-fetch');
const FormData = require('form-data'); // Import FormData


//  ------------------ DATABASE & CONFIG ------------------
const saldoDatabase = './database/saldo.json';
const depositRequestsFile = './database/deposit_requests.json';
const pterodactylConfig = {
    apiUrl: 'YOUR_PTERODACTYL_API_URL', // Ganti dengan URL API Pterodactyl Anda
    apiKey: 'YOUR_PTERODACTYL_API_KEY',  // Ganti dengan API Key Pterodactyl Anda
    serverIdTemplate: 'YOUR_SERVER_ID_TEMPLATE', // Ganti dengan template ID server (contoh: server-{{senderNumber}})
    nodeId: 'YOUR_PTERODACTYL_NODE_ID', // Ganti dengan Node ID Pterodactyl
    eggId: 'YOUR_PTERODACTYL_EGG_ID', // Ganti dengan Egg ID Pterodactyl
    memory: 1024, // RAM (MB)
    disk: 5000, // Disk (MB)
    cpu: 100, // CPU (%)
    portRangeStart: 27000, // Port Range Start
    portRangeEnd: 28000, // Port Range End
};
// Load saldo, create if not exists
if (!fs.existsSync(saldoDatabase)) {
    fs.writeFileSync(saldoDatabase, JSON.stringify({}, null, 2));
}
if (!fs.existsSync(depositRequestsFile)) {
    fs.writeFileSync(depositRequestsFile, JSON.stringify([], null, 2));
}
let autoAIPrivate = true;
let lastAutoAI = {};
let autoAI = {};
let autoAIGroup = {};


let saldoCooldown = {};
let saldo = JSON.parse(fs.readFileSync(saldoDatabase));
let depositRequests = JSON.parse(fs.readFileSync(depositRequestsFile));

function saveData() {
    fs.writeFileSync(saldoDatabase, JSON.stringify(saldo, null, 2));
    fs.writeFileSync(depositRequestsFile, JSON.stringify(depositRequests, null, 2));
}

function generateDepositRequestId() {
    return 'dep-' + Math.random().toString(36).substring(2, 15);
}

//  ------------------ HELPER FUNCTIONS ------------------

// Function to save data
function saveData() {
    fs.writeFileSync(saldoDatabase, JSON.stringify(saldo, null, 2));
    fs.writeFileSync(depositRequestsFile, JSON.stringify(depositRequests, null, 2));
}

function generateTransactionID(length = 10) {
    let chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let id = '';
    for (let i = 0; i < length; i++) {
        id += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return id;
}
function createSerial(length) {
    let result = "";
    let characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}

async function fetchJson(url, options) {
    try {
        const res = await fetch(url, options);
        return await res.json();
    } catch (err) {
        throw err;
    }
}

function runtime(seconds) {
    seconds = Number(seconds);
    let d = Math.floor(seconds / (3600 * 24));
    let h = Math.floor((seconds % (3600 * 24)) / 3600);
    let m = Math.floor((seconds % 3600) / 60);
    let s = Math.floor(seconds % 60);
    return `${d}d ${h}h ${m}m ${s}s`;
}


// Function to send a message to the owner
async function sendToOwner(wanzofc, message, media = null) {
    try {
        const ownerNumbers = config.owner.map(owner => owner.replace(/[^0-9]/g, '') + '@s.whatsapp.net'); // Ensure owner numbers are in the correct format
        if (!ownerNumbers || ownerNumbers.length === 0) {
            console.warn('No owner numbers configured in config.js. Cannot send message.');
            return;
        }

        for (const ownerNumber of ownerNumbers) {
            if (media) {
                await wanzofc.sendMessage(ownerNumber, { ...media, caption: message });
            } else {
                await wanzofc.sendMessage(ownerNumber, { text: message });
            }
        }
    } catch (error) {
        console.error('Error sending message to owner:', error);
    }
}

// Function to generate a unique ID for the deposit request
function generateDepositRequestId() {
    return 'dep-' + Math.random().toString(36).substring(2, 15);
}


//  ------------------ PTERODACTYL FUNCTIONS ------------------

// Function to create a Pterodactyl server
async function createPterodactylServer(senderNumber, amount) {
    try {
        const serverId = pterodactylConfig.serverIdTemplate.replace('{{senderNumber}}', senderNumber).replace(/[^a-zA-Z0-9-]/g, '');
        const serverName = `Server ${senderNumber} - ${amount} Saldo`; // Adjust as needed
        const data = {
            name: serverName,
            user: '1', // Replace with actual user ID from Pterodactyl (hardcoded for now)
            egg: pterodactylConfig.eggId,
            docker_image: 'ghcr.io/pterodactyl/core:latest', // Example:  Use the appropriate image
            startup: './start.sh', // Set the correct startup command
            limits: {
                memory: pterodactylConfig.memory,
                swap: 0,
                disk: pterodactylConfig.disk,
                io: 500,
                cpu: pterodactylConfig.cpu,
            },
            feature_limits: {
                databases: 0,
                allocations: 1,
                backups: 0,
            },
            deploy: {
                locations: [pterodactylConfig.nodeId],
                dedicated_ip: false,
                port_range: [pterodactylConfig.portRangeStart, pterodactylConfig.portRangeEnd],
            },
        };

        const response = await axios.post(`${pterodactylConfig.apiUrl}/api/application/servers`, data, {
            headers: {
                'Authorization': `Bearer ${pterodactylConfig.apiKey}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
        });
        if (response.status !== 201) {
            console.error('Pterodactyl server creation failed:', response.data);
            return { success: false, message: 'Gagal membuat server di Pterodactyl.' };
        }
        return { success: true, message: 'Server Pterodactyl berhasil dibuat!', serverId: serverId, serverName: serverName };
    } catch (error) {
        console.error('Error creating Pterodactyl server:', error.response?.data || error.message);
        return { success: false, message: 'Terjadi kesalahan saat membuat server di Pterodactyl.' };
    }
}


module.exports = async (wanzofc, m) => {
    try {
        const body = (
            m.mtype === 'conversation' && m.message.conversation ||
            m.mtype === 'imageMessage' && m.message.imageMessage.caption ||
            m.mtype === 'documentMessage' && m.message.documentMessage.caption ||
            m.mtype === 'videoMessage' && m.message.videoMessage.caption ||
            m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text ||
            m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId ||
            m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId ||
            m.mtype === 'listResponseMessage' && m.message.listResponseMessage.singleSelectReply.selectedRowId ||
            m.mtype === 'interactiveResponseMessage' && m.message.interactiveResponseMessage.nativeFlowResponse.selectedId
        ) || '';
        const chatId = m.chat || m.key.remoteJid;
        if (!chatId || typeof chatId !== "string") return console.error("Chat ID tidak valid!");
        const budy = typeof m.text === 'string' ? m.text : '';
        const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><™©®Δ^βα~¦|/\©^]/;
        const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '';
        const isCmd = body.startsWith(prefix);
        const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
        const args = body.trim().split(/ +/).slice(1);
        const text = args.join(" ");
        const sender = m.key.fromMe ? wanzofc.user.id.split(':')[0] + '@s.whatsapp.net' : (m.key.participant || m.key.remoteJid);
        const botNumber = await wanzofc.decodeJid(wanzofc.user.id);
        const senderNumber = sender.split('@')[0];
        const isOwner = [botNumber, ...(global.owner || [])].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(sender);
        const pushname = m.pushName || senderNumber;
        const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));


        const qproduk = {
            key: {
                participant: '0@s.whatsapp.net',
                ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
            },
            message: {
                "productMessage": {
                    "product": {
                        "productImage": {
                            "mimetype": "image/jpeg",
                            "jpegThumbnail": fs.readFileSync("./media/produk.png") // Ganti dengan path gambar produk
                        },
                        "title": "𝙰𝚂𝙷𝙴𝙽 𝚆𝙸𝚃𝙲𝙷 - 𝙼𝙳",
                        "description": "BAYMAX",
                        "currencyCode": "IDR",
                        "priceAmount1000": 999999999,
                        "retailerId": "BAYMAX",
                        "productImageCount": 9999999999
                    },
                    "businessOwnerJid": "62815867727093@s.whatsapp.net" // Nomor admin toko
                }
            }
        };
        const qkeranjang = {
            key: {
                participant: '0@s.whatsapp.net',
                ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
            },
            message: {
                "orderMessage": {
                    "orderId": "999999999",
                    "thumbnail": fs.readFileSync("./media/produk.png"), // Thumbnail produk
                    "itemCount": 999999999, // Jumlah item dalam pesanan
                    "status": 1,
                    "surface": 1,
                    "message": "𝙰𝚂𝙷𝙴𝙽 𝚆𝙸𝚃𝙲𝙷 - 𝙼𝙳"
                }
            }
        };
        const qtext = { key: { fromMe: false, participant: '0@s.whatsapp.net', ...(m.chat ? { remoteJid: "0@s.whatsapp.net" } : {}) }, 'message': { extendedTextMessage: { text: body } } }
        const qdoc = { key: { participant: '0@s.whatsapp.net', ...(m.chat ? { remoteJid: 'status@broadcast' } : {}) }, message: { documentMessage: { title: `_*𝙰𝚂𝙷𝙴𝙽 𝚆𝙸𝚃𝙲𝙷 - 𝙼𝙳*_`, jpegThumbnail: "" } } }
        const qlive = { key: { participant: '0@s.whatsapp.net', ...(m.chat ? { remoteJid: 'status@broadcast' } : {}) }, message: { liveLocationMessage: { caption: `*𝙰𝚂𝙷𝙴𝙽 𝚆𝙸𝚃𝙲𝙷 - 𝙼𝙳*`, jpegThumbnail: "" } } }


        switch (command) {
            case "wan": case "menu": {
                let textnya = `Halo ${pushname}, SAYA 𝙰𝚂𝙷𝙴𝙽 𝚆𝙸𝚃𝙲𝙷 - 𝙼𝙳*

────── [ owner menu ] ──────

stopspam

spamtag

self

public

────── [ download menu ] ─────

tiktok

mediafire

ytmp3

ytmp4

songs

snackvideo

────── [ stalking menu ] ─────

igstalk

`;

                await wanzofc.sendMessage(m.chat, {
                    footer: '𝙰𝚂𝙷𝙴𝙽 𝚆𝙸𝚃𝙲𝙷 - 𝙼𝙳',
                    headerType: 1,
                    viewOnce: true,
                    document: fs.readFileSync("./package.json"),
                    fileName: '𝙰𝚂𝙷𝙴𝙽 𝚆𝙸𝚃𝙲𝙷 - 𝙼𝙳 </>',
                    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    caption: textnya,
                    contextInfo: {
                        isForwarded: true,
                        mentionedJid: [m.sender],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: global.idSaluran,
                            newsletterName: global.namaSaluran
                        },
                        externalAdReply: {
                            title: '𝙰𝚂𝙷𝙴𝙽 𝚆𝙸𝚃𝙲𝙷 - 𝙼𝙳',
                            body: `Runtime: ${runtime(process.uptime())}`,
                            thumbnailUrl: global.image,
                            mediaType: 1,
                            renderLargerThumbnail: true,
                        }
                    }
                }, { quoted: qlive });
                try {
                    let audioPath = "./media/menu.mp3"; // Pastikan file ini ada
                    let audioBuffer = fs.readFileSync(audioPath);

                    await wanzofc.sendMessage(m.chat, {
                        audio: audioBuffer,
                        mimetype: "audio/mpeg",
                        ptt: true // true = voice note, false = audio biasa
                    }, { quoted: qlive });


                } catch (err) {
                    console.error("Gagal mengirim audio:", err);
                    await wanzofc.sendMessage(m.chat, { text: "❌ Gagal mengirim audio!" }, { quoted: qlive });
                }
            }
            break;
     case 'mysaldo': {
                const userSaldo = saldo[senderNumber] || 0;
                m.reply(`💰 Saldo kamu: Rp ${userSaldo.toLocaleString()}`);
            }
            break;

            case 'myid': {
                m.reply(`ID WhatsApp kamu:\n\n*${sender}*`);
            }
            break;

            case 'myserver': {
                const serverId = `server-${senderNumber}`;
                m.reply(`Server ID kamu:\n\n*${serverId}*`);
            }
            break;

            case 'topup': {
                const depositRequestId = generateDepositRequestId();
                depositRequests.push({
                    id: depositRequestId,
                    sender: sender,
                    nominal: 2000,
                    status: 'pending',
                    time: Date.now()
                });
                saveData();

                await wanzofc.sendMessage(m.chat, {
                    text: `Silakan transfer Rp 2.000 ke QR berikut.\n\nSetelah transfer, kirim:\n\n*.cekdeposit ${depositRequestId}*`
                });

                await wanzofc.sendMessage(m.chat, {
                    image: fs.readFileSync('./media/qris.jpg'),
                    caption: `Scan QR ini untuk transfer\n\nID Deposit: *${depositRequestId}*`
                });

                // Notifikasi ke owner
                if (Array.isArray(global.owner)) {
                    for (let nomor of global.owner) {
                        let jid = nomor.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
                        await wanzofc.sendMessage(jid, {
                            text: `📥 Permintaan deposit baru!\n\nDari: wa.me/${senderNumber}\nID: ${depositRequestId}\nNominal: Rp 2.000`
                        });
                    }
                }
            }
            break;

            case 'cekdeposit': {
                if (!args[0]) return m.reply('Masukkan ID Deposit.\nContoh: *.cekdeposit dep-xxxxx*');
                const depositRequestId = args[0];
                const index = depositRequests.findIndex(r => r.id === depositRequestId && r.sender === sender);

                if (index === -1) return m.reply('❌ ID Deposit tidak ditemukan atau bukan milikmu.');

                const nominal = depositRequests[index].nominal || 2000;
                saldo[senderNumber] = (saldo[senderNumber] || 0) + nominal;
                depositRequests.splice(index, 1);
                saveData();

                m.reply(`✅ Deposit berhasil Rp ${nominal.toLocaleString()}\nSaldo kamu sekarang: Rp ${saldo[senderNumber].toLocaleString()}`);
            }
            break;


case 'igstalk': {
  if (!args[0]) return m.reply('Masukkan Username Yamg Ingin Di Stalk\n\n*Example : .igstalk jokowi*');
  
  try {
    const query = args[0];
    const endpoint = 'https://privatephotoviewer.com/wp-json/instagram-viewer/v1/fetch-profile';
    const payload = { find: query };
    const headers = {
      'Content-Type': 'application/json',
      'Accept': '*/*',
      'X-Requested-With': 'XMLHttpRequest',
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36',
      'Referer': 'https://privatephotoviewer.com/'
    };

    const { data } = await axios.post(endpoint, payload, { headers });
    const html = data.html;
    const $ = cheerio.load(html);
    let profilePic = $('#profile-insta').find('.col-md-4 img').attr('src');
    if (profilePic && profilePic.startsWith('//')) {
      profilePic = 'https:' + profilePic;
    }
    const name = $('#profile-insta').find('.col-md-8 h4.text-muted').text().trim();
    const username = $('#profile-insta').find('.col-md-8 h5.text-muted').text().trim();
    const stats = {};
    $('#profile-insta')
      .find('.col-md-8 .d-flex.justify-content-between.my-3 > div')
      .each((i, el) => {
        const statValue = $(el).find('strong').text().trim();
        const statLabel = $(el).find('span.text-muted').text().trim().toLowerCase();
        if (statLabel.includes('posts')) {
          stats.posts = statValue;
        } else if (statLabel.includes('followers')) {
          stats.followers = statValue;
        } else if (statLabel.includes('following')) {
          stats.following = statValue;
        }
      });
    const bio = $('#profile-insta').find('.col-md-8 p').text().trim();

    let caption = `- *Name :* ${name}\n`
    caption += `- *Username :* ${username}\n`
    caption += `- *Posts :* ${stats.posts}\n`
    caption += `- *Followers :* ${stats.followers}\n`
    caption += `- *Following :* ${stats.following}\n`
    caption += `- *Bio :* ${bio}`;
    
    if (profilePic) {
      await wanzofc.sendMessage(m.chat, { 
        image: { url: profilePic },
        caption: caption
      }, { quoted: m });
    } else {
      await m.reply(caption);
    }
  } catch (error) {
    m.reply('Tidak Ada Akun Tersebut Atau Error');
  }
}
break;
            case 'verifdeposit': {
                if (!isOwner) return m.reply('Perintah ini hanya untuk owner.');
                if (!m.quoted || !m.quoted.imageMessage) return m.reply('Reply pesan dengan bukti transfer.');

                const quotedMessage = m.quoted;
                const depositRequestIdMatch = quotedMessage.text && quotedMessage.text.match(/\*([a-zA-Z0-9-]+)\*/);
                const depositRequestId = depositRequestIdMatch ? depositRequestIdMatch[1] : null;

                if (!depositRequestId) {
                    return m.reply('ID Deposit tidak ditemukan dalam pesan yang dikutip.');
                }
                const depositRequestIndex = depositRequests.findIndex(req => req.id === depositRequestId);

                if (depositRequestIndex === -1) {
                    return m.reply('Permintaan deposit dengan ID tersebut tidak ditemukan.');
                }

                const depositRequest = depositRequests[depositRequestIndex];
                const senderNumber = depositRequest.sender.split('@')[0];

                const imageBuffer = await wanzofc.downloadMediaMessage(quotedMessage);
                const media = { image: imageBuffer, mimetype: quotedMessage.mimetype };

                //  Get the amount from the user (you'll need a way to get this from the user input,  e.g., asking them to specify in the original message)
                const amount = parseInt(args[0]) || 10000; // Default amount, or get it from args

                if (isNaN(amount) || amount <= 0) {
                    return m.reply('Silakan masukkan jumlah deposit yang valid (angka).');
                }

                //  Add saldo
                if (!saldo[senderNumber]) {
                    saldo[senderNumber] = 0;
                }
                saldo[senderNumber] += amount;
                saveData();

                //  Optional: Create a Pterodactyl server
                const pterodactylResult = await createPterodactylServer(senderNumber, amount);
                let pterodactylMessage = '';

                if (pterodactylResult.success) {
                    pterodactylMessage = `\n✅ Server Pterodactyl berhasil dibuat!\nID Server: ${pterodactylResult.serverId}\nNama Server: ${pterodactylResult.serverName}`;
                } else {
                    pterodactylMessage = `\n⚠️ Gagal membuat server Pterodactyl: ${pterodactylResult.message}`;
                }

                //  Remove deposit request from the list
                depositRequests.splice(depositRequestIndex, 1);
                saveData();

                await wanzofc.sendMessage(
                    depositRequest.sender,
                    {
                        text: `✅ Deposit sebesar Rp ${amount.toLocaleString()} berhasil!\nSaldo Anda saat ini: Rp ${saldo[senderNumber].toLocaleString()}${pterodactylMessage}`,
                        ...media
                    }
                );
                //  Send message to owner
                await sendToOwner(wanzofc, `✅ Deposit dari ${senderNumber} sebesar Rp ${amount.toLocaleString()} telah disetujui.  ${pterodactylMessage} \nBukti:`, media);
            }
            break;
case 'autoai': {
    const senderNumber = sender.split('@')[0];
    if (!args[0]) return m.reply('Contoh: autoai on / autoai off');
    if (args[0] === 'on') {
        autoAI[sender] = true;
        m.reply('✅ AutoAI pribadi diaktifkan.');
    } else if (args[0] === 'off') {
        delete autoAI[sender];
        m.reply('❌ AutoAI pribadi dinonaktifkan.');
    }
}
break;

case 'autoaigrup': {
    if (!m.isGroup) return m.reply('Hanya bisa dipakai di grup.');
    if (!args[0]) return m.reply('Contoh: autoaigrup on / autoaigrup off');
    if (args[0] === 'on') {
        autoAIGroup[m.chat] = true;
        m.reply('✅ AutoAI grup diaktifkan.');
    } else if (args[0] === 'off') {
        delete autoAIGroup[m.chat];
        m.reply('❌ AutoAI grup dinonaktifkan.');
    }
}
break;

           case 'saldo': {
    const senderNumber = sender.split('@')[0];
    const now = Date.now();

    if (saldoCooldown[senderNumber] && now - saldoCooldown[senderNumber] < 5000) {
        return m.reply('⏱️ Tunggu 5 detik sebelum cek saldo lagi.');
    }

    saldoCooldown[senderNumber] = now;

    const userSaldo = saldo[senderNumber] || 0;
    await wanzofc.sendMessage(m.chat, {
        text: `💰 Saldo Anda: Rp ${userSaldo.toLocaleString()}`
    });
}
break;

            case 'tiktok': {
                if (!args[0]) return m.reply('Masukkan link TikTok!\nContoh: ${prefix} https://vt.tiktok.com/xxx');

                let url = args[0]
                if (!url.includes('tiktok.com')) throw 'Link tidak valid, pastikan dari TikTok.'

                try {
                    let res = await fetch(`https://www.velyn.biz.id/api/downloader/tiktok?url=${encodeURIComponent(url)}`)
                    let json = await res.json()

                    if (!json.status || !json.data || !json.data.no_watermark) {
                        throw 'Gagal mengambil data. Pastikan link benar dan coba lagi.'
                    }

                    let { title, music, no_watermark, cover } = json.data
                    let caption = `✅ Video TikTok berhasil diunduh\n\n📌 Judul: ${title || '-'}\n🔗 Link: ${url}`

                    if (m.isGroup) {
                        await conn.reply(m.chat, '✅ Video berhasil didapat! Aku kirim ke private chat ya~', m)
                    }

                    await wanzofc.sendFile(m.sender, no_watermark, 'tiktok.mp4', caption, m)
                    

                } catch (err) {
                    console.log(err)
                    throw `❌ Error\nLogs error : ${err.message || err}`
                }
            }
            break
      
case 'owner': {
let name = m.pushName || wanzofc.getName(m.sender);
let pan = `
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
> *Halo Kak \`${name}\`, Tekan Tombol Yang bertuliskan Chat Owner Untuk Menghubungi Nomor Owner ku*
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
`;
const url = fs.readFileSync("thumb.jpg")
async function image(url) {
  const { imageMessage } = await generateWAMessageContent({
    image: {
      url
    }
  }, {
    upload: wanzofc.waUploadToServer
  });
  return imageMessage;
}
let msg = generateWAMessageFromContent(
  m.chat,
  {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: pan
          },
          carouselMessage: {
            cards: [
              {
                header: proto.Message.InteractiveMessage.Header.create({
          ...(await prepareWAMessageMedia({ image: { url: 'thumb.jpg' } }, { upload: wanzofc.waUploadToServer })),
          title: ``,
          gifPlayback: true,
          subtitle: global.name,
          hasMediaAttachment: false
        }),
                body: {
                  text: `
┏───────────────┈ 
┆     「 *\`[OWNER BOT]\`* 」
┣───────────────┈ 
┣──=[ *\`[ ${global.ownername} ]\`* ]==─
┆ • Jangan Chat Yang Aneh Aneh
┆ • Jangan Telpon/Call Owner 
┆ • Chat Langsung ke intinya aja
┆ • Klo Ada Uang Minimal Bagi
└────────────┈ ⳹`
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: `{"display_text":"👤 Chat Owner ( ${global.ownername} )","url":"https://wa.me/${global.ownernumber}","merchant_url":"https://wa.me/${global.ownernumber}"}`
                    },
                  ],
                },
              },
              {
                header: proto.Message.InteractiveMessage.Header.create({
          ...(await prepareWAMessageMedia({ image: { url: 'thumb.jpg' } }, { upload: wanzofc.waUploadToServer })),
          title: ``,
          gifPlayback: true,
          subtitle: global.name,
          hasMediaAttachment: false
        }),
                body: {
                  text: `
┏───────────────┈ 
┆     「 *\`[NOMOR BOT]\`* 」
┣───────────────┈ 
┣──=[ *\`[ ${botname} ]\`* ]==─
┆ • Jangan Spam Bot
┆ • Jangan Telpon/Call Bot 
┆ • Gaudah Chat Yg Aneh Aneh
┆ • Beli Prem Dll Chat Owner
└────────────┈ ⳹`
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: `{"display_text":"  💬  Chat Bot ( ${botname} )","url":"https://wa.me/${global.botnumber}","merchant_url":"https://wa.me/${global.botnumber}"}`
                    },
                  ],
                },
              },
            ],
            messageVersion: 1,
          },
        },
      },
    },
  },
  {}
);

await wanzofc.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id,
});

}
break
//--------------------------------------------------------------------//

case "tozip": {
    if (!isOwner) return m.reply(msg.owner);
    if (!text) return m.reply('Linknya?');

    await reply('⏳ Sedang mengekstrak ke zip, mohon tunggu...');

    try {
        const fs = require('fs');
        const path = require('path');
        const archiver = require('archiver');
        const axios = require('axios');
        const url = require('url');

        const tempDir = './temp';
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }

        const fileUrl = text.trim();
        const parsedUrl = url.parse(fileUrl);
        let fileName = path.basename(parsedUrl.pathname);

        if (!fileName || !fileName.includes('.')) {
            fileName = `${pushname}.zip`;
        }

        const filePath = path.join(tempDir, fileName);
        const response = await axios.get(fileUrl, { responseType: 'stream' });

        const disposition = response.headers['content-disposition'];
        if (disposition && disposition.includes('filename=')) {
            const match = disposition.match(/filename="?(.+?)"?$/);
            if (match) fileName = match[1];
        }

        const writer = fs.createWriteStream(filePath);
        response.data.pipe(writer);

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        const zipPath = path.join(tempDir, `${pushname}.zip`);
        const output = fs.createWriteStream(zipPath);
        const archive = archiver('zip', { zlib: { level: 9 } });

        archive.pipe(output);
        archive.file(filePath, { name: fileName });

        await new Promise((resolve, reject) => {
            output.on('close', resolve);
            archive.on('error', reject);
            archive.finalize();
        });

        await wanzofc.sendMessage(m.chat, {
            document: fs.readFileSync(zipPath),
            fileName: `${pushname}.zip`,
            mimetype: 'application/zip',
            caption: `✅ File dari URL berhasil diubah ke ZIP!`,
        }, { quoted: m });

        fs.unlinkSync(filePath);
        fs.unlinkSync(zipPath);

    } catch (err) {
        console.error('Error creating ZIP from URL:', err);
        m.reply(`❌ Terjadi kesalahan:\n${err.message}`);
    }
}
break
            case 'spamtag': {
                if (!isOwner) return m.reply('Perintah ini hanya bisa digunakan oleh owner bot!')
                if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di dalam grup!')
                if (!text.includes('|')) return m.reply('Format salah!\nGunakan: .spamtag 628xxx/@tag|jumlah|pesan')

                let [targetRaw, jumlahRaw, ...pesanArray] = text.split('|')
                let jumlah = parseInt(jumlahRaw.trim())
                let pesan = pesanArray.join('|').trim()

                if (!targetRaw || isNaN(jumlah) || jumlah < 1 || !pesan)
                    return m.reply('Format salah!\nGunakan: .spamtag 628xxx/@tag|jumlah|pesan')

                let target = targetRaw.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                const chatId = m.chat

                // Inisialisasi kalau belum ada
                if (!sock.spamStatus) sock.spamStatus = {}
                sock.spamStatus[chatId] = true

                for (let i = 1; i <= jumlah; i++) {
                    if (!sock.spamStatus[chatId]) break
                    await sock.sendMessage(chatId, {
                        text: `#${i} ${pesan}\n@${target.split('@')[0]}`,
                        mentions: [target]
                    }, { quoted: m })
                    await new Promise(res => setTimeout(res, 1000))
                }

                delete sock.spamStatus[chatId]
            }
            break

            case 'stopspam': {
                if (!isOwner) return m.reply('Perintah ini hanya bisa digunakan oleh owner bot!')
                if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di dalam grup!')
                if (!sock.spamStatus) sock.spamStatus = {}

                const chatId = m.chat
                if (wanzofc.spamStatus[chatId]) {
                    delete wanzofc.spamStatus[chatId]
                    m.reply('Spam tag berhasil dihentikan!')
                } else {
                    m.reply('Tidak ada spam tag yang sedang berjalan.')
                }
            }
            break

case 'brat-gen': {
 if (!text) return m.reply('Masukkan teks untuk stiker.');
 const axios = require('axios')
 const { createCanvas, loadImage, registerFont } = require('canvas')
 const sharp = require('sharp')
 try {
 let imageUrl = 'https://cloudkuimages.com/uploads/images/67ddbbcb065a6.jpg';
 let fontUrl = 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf';
 let imagePath = path.join(__dirname, 'session', 'file.jpg');
 let fontPath = path.join(__dirname, 'session', 'NotoColorEmoji.ttf');
 let outputMp4 = path.join(__dirname, 'session', `output_${Date.now()}.mp4`);
 let outputWebP = path.join(__dirname, 'session', `animated_${Date.now()}.webp`);
 let frameDir = path.join(__dirname, 'session', `frames_${Date.now()}`);

 if (!fs.existsSync(frameDir)) fs.mkdirSync(frameDir);

 if (!fs.existsSync(fontPath)) {
 let fontData = await axios.get(fontUrl, { responseType: 'arraybuffer' });
 fs.writeFileSync(fontPath, Buffer.from(fontData.data));
 }

 let response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
 fs.writeFileSync(imagePath, Buffer.from(response.data));

 let baseImage = await loadImage(imagePath);
 let canvas = createCanvas(baseImage.width, baseImage.height);
 let ctx = canvas.getContext('2d');

 require('canvas').registerFont(fontPath, { family: 'EmojiFont' });

 let boardX = canvas.width * 0.22;
 let boardY = canvas.height * 0.50;
 let boardWidth = canvas.width * 0.56;
 let boardHeight = canvas.height * 0.25;

 ctx.fillStyle = '#000';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'middle';

 let maxFontSize = 32;
 let minFontSize = 12;
 let fontSize = maxFontSize;

 function isTextFit(text, fontSize) {
 ctx.font = `bold ${fontSize}px EmojiFont`;
 let words = text.split(' ');
 let lineHeight = fontSize * 1.2;
 let maxWidth = boardWidth * 0.9;
 let lines = [];
 let currentLine = words[0];

 for (let i = 1; i < words.length; i++) {
 let testLine = currentLine + ' ' + words[i];
 let testWidth = ctx.measureText(testLine).width;
 if (testWidth > maxWidth) {
 lines.push(currentLine);
 currentLine = words[i];
 } else {
 currentLine = testLine;
 }
 }
 lines.push(currentLine);
 let textHeight = lines.length * lineHeight;
 return textHeight <= boardHeight * 0.9;
 }

 while (!isTextFit(text, fontSize) && fontSize > minFontSize) {
 fontSize -= 2;
 }

 ctx.font = `bold ${fontSize}px EmojiFont`;

 let words = text.split(' ');
 let lineHeight = fontSize * 1.2;
 let maxWidth = boardWidth * 0.9;
 let frames = [];

 for (let i = 1; i <= words.length; i++) {
 let tempText = words.slice(0, i).join(' ');
 let frameCanvas = createCanvas(baseImage.width, baseImage.height);
 let frameCtx = frameCanvas.getContext('2d');

 frameCtx.drawImage(baseImage, 0, 0, frameCanvas.width, frameCanvas.height);
 frameCtx.fillStyle = '#000';
 frameCtx.textAlign = 'center';
 frameCtx.textBaseline = 'middle';
 frameCtx.font = `bold ${fontSize}px EmojiFont`;

 let lines = [];
 let currentLine = '';
 tempText.split(' ').forEach((word) => {
 let testLine = currentLine ? currentLine + ' ' + word : word;
 let testWidth = frameCtx.measureText(testLine).width;
 if (testWidth > maxWidth) {
 lines.push(currentLine);
 currentLine = word;
 } else {
 currentLine = testLine;
 }
 });
 lines.push(currentLine);

 let startY = boardY + boardHeight / 2 - (lines.length - 1) * lineHeight / 2;
 lines.forEach((line, index) => {
 frameCtx.fillText(line, boardX + boardWidth / 2, startY + index * lineHeight);
 });

 let framePath = path.join(frameDir, `frame${i}.png`);
 fs.writeFileSync(framePath, frameCanvas.toBuffer('image/png'));
 frames.push(framePath);
 }

 exec(`ffmpeg -y -framerate 2 -i ${frameDir}/frame%d.png -c:v libx264 -pix_fmt yuv420p ${outputMp4}`, async (err) => {
 if (err) {
 console.error("❌ Error membuat video:", err);
 return m.reply("Terjadi kesalahan saat membuat video animasi.");
 }

 exec(`ffmpeg -i ${outputMp4} -vf "scale=512:512:flags=lanczos,format=rgba" -loop 0 -preset default -an -vsync 0 ${outputWebP}`, async (err) => {
 if (err) {
 console.error("❌ Error konversi video ke stiker:", err);
 return m.reply("Terjadi kesalahan saat mengonversi video ke stiker.");
 }

 wanzofc.sendMessage(m.chat, { sticker: { url: outputWebP } }, { quoted: m });

 setTimeout(() => {
 fs.unlinkSync(imagePath);
 fs.unlinkSync(outputMp4);
 fs.unlinkSync(outputWebP);
 fs.rmSync(frameDir, { recursive: true, force: true });
 }, 5000);
 });
 });

 } catch (e) {
 console.error(e);
 m.reply('⚠️ Terjadi kesalahan saat membuat stiker.');
 }
}
break;
case "pin": case "pintesert": {
if (!text) return m.reply("Masukan Query")
 async function createImage(url) {
    try {
        const { imageMessage } = await generateWAMessageContent({
            image: {
                url
            }
        }, {
            upload: wanzofc.waUploadToServer
        });
        return imageMessage;
    } catch (error) {
        console.error(error);
        return null;
    }
}
async function sendPinterestImages(text, m) {
    try {
        let push = [];
        let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
        let res = data.resource_response.data.results.map(v => v.images.orig.url);
        shuffleArray(res); 
        let ult = res.splice(0, 5); 
        let i = 1;
        for (let lucuy of ult) {
            const imageMessage = await createImage(lucuy);
            if (imageMessage) {
                push.push({
                    body: proto.Message.InteractiveMessage.Body.fromObject({
                        text: `Image ke - ${i++}`
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.fromObject({
                        text: ""
                    }),
                    header: proto.Message.InteractiveMessage.Header.fromObject({
                        title: 'Hasil.',
                        hasMediaAttachment: true,
                        imageMessage: imageMessage
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: [
                            {
                                "name": "cta_url",
                                "buttonParamsJson": `{"display_text":"Source","url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}","merchant_url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}"}`
                            }
                        ]
                    })
                });
            }
        }

        const bot = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: "Ilustrasi Dari Anda inginkan"
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "5 Image -"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            hasMediaAttachment: false
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: [
                                ...push
                            ]
                        })
                    })
                }
            }
        }, {});

        wanzofc.relayMessage(m.chat, bot.message, {
            messageId: bot.key.id
        });

    } catch (error) {
        console.log(error)
    }
}
sendPinterestImages(text, m);
}
break
case 'tiktokstalk':
{
 if (!text) m.reply (`Masukkan username TikTok!\nContoh: .${command} wanzofc`);
 const url = `https://api.alvianuxio.eu.org/api/tiktok/stalk?search=${encodeURIComponent(text)}&apikey=au-TMIQYF4L`;

 try {
 const { data } = await axios.get(url);
 const userInfo = JSON.parse(data?.data?.response)?.userInfo;
 if (!userInfo) throw 'User tidak ditemukan!';

 const stats = userInfo.statistik;

 const caption = `
╭─〔 *TIKTOK STALK* 〕
│ 👤 *Username:* @${userInfo.username}
│ 🏷️ *Nama:* ${userInfo.nama}
│ 🆔 *ID:* ${userInfo.id}
│ 📌 *Bio:* ${userInfo.bio || '-'}
│ ✅ *Verified:* ${userInfo.verifikasi ? 'Ya' : 'Tidak'}
│ 
│ ❤️ *Followers:* ${stats.totalFollowers}
│ 🔁 *Following:* ${stats.totalMengikuti}
│ ❤️ *Likes:* ${stats.totalDisukai}
│ 🎞️ *Videos:* ${stats.totalVideo}
│ 🤝 *Teman:* ${stats.totalTeman}
╰──────•••
🔗 https://www.tiktok.com/@${userInfo.username}
`.trim();

 await wanzofc.sendFile(m.chat, userInfo.avatar, 'tiktok.jpg', caption, m);
 } catch (e) {
 console.error(e);
 throw 'Gagal mengambil data. Username mungkin salah atau API error.';
 }
};
break

case "hitam": {
 if (!m.quoted) return m.reply(`Kirim/reply gambar dengan caption *${prefix + command}*`);
 const { GoogleGenerativeAI } = require ("@google/generative-ai");
 let mime = m.quoted.mimetype || "";
 let defaultPrompt = "Ubahlah Karakter Dari Gambar Tersebut Diubah Kulitnya Menjadi Hitam se hitam-hitam nya";

 if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`);

 let promptText = text || defaultPrompt;
 m.reply("Otw Menghitam...");

 try {
 let imgData = await m.quoted.download();
 let genAI = new GoogleGenerativeAI("AIzaSyDdfNNmvphdPdHSbIvpO5UkHdzBwx7NVm0");

 const base64Image = imgData.toString("base64");

 const contents = [
 { text: promptText },
 {
 inlineData: {
 mimeType: mime,
 data: base64Image
 }
 }
 ];

 const model = genAI.getGenerativeModel({
 model: "gemini-2.0-flash-exp-image-generation",
 generationConfig: {
 responseModalities: ["Text", "Image"]
 },
 });

 const response = await model.generateContent(contents);

 let resultImage;
 let resultText = "";

 for (const part of response.response.candidates[0].content.parts) {
 if (part.text) {
 resultText += part.text;
 } else if (part.inlineData) {
 const imageData = part.inlineData.data;
 resultImage = Buffer.from(imageData, "base64");
 }
 }

 if (resultImage) {
 const tempPath = `./tmp/gemini_${Date.now()}.png`;
 fs.writeFileSync(tempPath, resultImage);

 await wanzofc.sendMessage(m.chat, { 
 image: { url: tempPath },
 caption: `*berhasil menghitamkan*`
 }, { quoted: m });

 setTimeout(() => {
 try {
 fs.unlinkSync(tempPath);
 } catch {}
 }, 30000);
 } else {
 m.reply("Gagal Menghitamkan.");
 }
 } catch (error) {
 console.error(error);
 m.reply(`Error: ${error.message}`);
 }
}
break;

case 'tqto': {
 const audioUrl = 'https://files.catbox.moe/w2i31u.mp3';
 const thumbnailUrl = 'https://files.catbox.moe/kkedp7.jpeg'; 
 let tqtoo;

 try {

 const response = await axios.get(audioUrl, { responseType: 'arraybuffer' });
 tqtoo = response.data;
 } catch (error) {
 console.error('Error fetching audio file:', error);
 return wanzofc.sendMessage(m.chat, { text: 'Failed to fetch audio file.' });
 }

 const cu = `Geia sou Sis, edó eínai ta onómata pou échoun engrafeí sti dimiourgía/voítheia stin anáptyxi aftoú tou senaríou:

*BIG THANKS TO*

> 𝐊𝐀𝐈𝐙𝐄𝐋 [ 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 ] 

> 𝐖𝐀𝐍𝐙𝐎𝐅𝐂 [ 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 ] 

 

*𝐜𝐫𝐞𝐚𝐭𝐨𝐫 && 𝐝𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 𝐩𝐞𝐧𝐲𝐞𝐝𝐢𝐚 𝐚𝐩𝐢𝐤𝐞𝐲*

*𝐣𝐚𝐧𝐠𝐚𝐧 𝐥𝐮𝐩𝐚 𝐮𝐧𝐭𝐮𝐤 𝐤𝐞𝐭𝐢𝐤 .𝐩𝐚𝐲𝐦𝐞𝐧𝐭 𝐮𝐧𝐭𝐮𝐤 𝐝𝐨𝐧𝐚𝐬𝐢 𝐚𝐨𝐰𝐤𝐚𝐤𝐰𝐤𝐰*`;

 wanzofc.sendMessage(m.chat, {
 text: cu,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true,
 title: 'Thanks To',
 body: 'Special Thanks To',
 thumbnailUrl: thumbnailUrl, 
 sourceUrl: global.linkch || '',
 mediaType: 1,
 renderLargerThumbnail: true,
 },
 },
 });

 wanzofc.sendMessage(
 m.chat,
 { 
 audio: Buffer.from(tqtoo), 
 mimetype: 'audio/mpeg', 
 ptt: true, 
 viewOnce: false 
 },
 { quoted: m }
 );
}
 break;

case "play": {
if (!text) return m.reply("one of the girls")
m.reply("🔎 Memproses pencarian . .")
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]
var anu = await ytmp3(res.url)
if (anu.audio) {
let urlMp3 = anu.audio
await wanzofc.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
}
break

case "kick":{
if (m?.isGroup && !isAdmins && !isGroupOwner && isBotAdmins) return
if (!text && !m?.quoted) m.reply('masukkan nomor yang ingin di kick')
let users = m?.quoted ? m?.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await wanzofc.groupParticipantsUpdate(m?.chat, [users], 'remove').catch(console.log)
}
break

case 'ffstalk':{
wanzofc.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
if (!q) return m.reply(`Example ${prefix+command} 946716486`)
reply(mess.wait)
const data = await fetchJson(`https://api.yanzbotz.live/api/stalker/free-fire?id=${encodeURIComponent(text)}`)
const data1 = data.result
m.reply(`*/ Free Fire Stalker \\*

Id : ${q}
Nickname : ${data1}`)
}
break
case 'mlstalk': {
if (!text) return m.reply(`Contoh penggunaan:\n${prefix + command} id|zona id\n\nEx.\n${prefix + command} 157228049|2241`)
 async function mlstalk(id, zoneId) {
    return new Promise(async (resolve, reject) => {
      axios
        .post(
          'https://api.duniagames.co.id/api/transaction/v1/top-up/inquiry/store',
          new URLSearchParams(
            Object.entries({
              productId: '1',
              itemId: '2',
              catalogId: '57',
              paymentId: '352',
              gameId: id,
              zoneId: zoneId,
              product_ref: 'REG',
              product_ref_denom: 'AE',
            })
          ),
          {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              Referer: 'https://www.duniagames.co.id/',
              Accept: 'application/json',
            },
          }
        )
        .then((response) => {
          resolve(response.data.data.gameDetail)
        })
        .catch((err) => {
          reject(err)
        })
    })
}

var { userName } = await mlstalk(text.split('|')[0], text.split('|')[1]).catch(async _ => await m.reply("User tidak di temukan"))
var vf = `*MOBILE LEGENDS STALK*

*ID: ${text.split('|')[0]}*
*ZONA ID: ${text.split('|')[1]}*
*Username: ${userName ? userName : "Kosong"}*`
reply(vf)
         }
         break
case 'npmstalk':{
  reply(mess.wait)
if (!q) return m.reply(`Example ${prefix+command} wanzofc-hunter`)
m.reply(mess.wait)
eha = await npmstalk.npmstalk(q)
m.reply(`*/ Npm Stalker \\*

Name : ${eha.name}
Version Latest : ${eha.versionLatest}
Version Publish : ${eha.versionPublish}
Version Update : ${eha.versionUpdate}
Latest Dependencies : ${eha.latestDependencies}
Publish Dependencies : ${eha.publishDependencies}
Publish Time : ${eha.publishTime}
Latest Publish Time : ${eha.latestPublishTime}`)
}
break

case 'ttsearch': 
case 'tiktoksearch': {
 if (!text) return m.reply('Masukkan kata kunci pencarian!');
 try {
 const apiUrl = `https://www.ikyiizyy.my.id/api/search/tiktoksearch?q=${encodeURIComponent(text)}`;
 const res = await axios.get(apiUrl);
 if (!res.data.status || !res.data.result || !res.data.result.length) {
 return m.reply('Gagal menemukan video TikTok!');
 }
 const videos = res.data.result;
 await wanzofc.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

 for (let videoData of videos) {
 const videoUrl = videoData.play;
 const audioUrl = videoData.music_info.play;
 await wanzofc.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: `🔰 *TIKTOK VIDEO SEARCH* 🔰
📌 *Judul:* ${videoData.title}
👤 *Author:* ${videoData.author.nickname} (@${videoData.author.unique_id})
🎭 *Region:* ${videoData.region}
⏳ *Durasi:* ${videoData.duration} detik
📊 *Views:* ${videoData.play_count.toLocaleString()}
👍 *Likes:* ${videoData.digg_count.toLocaleString()}
💬 *Komentar:* ${videoData.comment_count.toLocaleString()}
📎 *URL Video:* ${videoUrl}`,
 thumbnail: { url: videoData.cover }
 }, { quoted: m });
 await wanzofc.sendMessage(m.chat, {
 audio: { url: audioUrl },
 mimetype: 'audio/mp4',
 fileName: `${videoData.music_info.title}.mp3`
 }, { quoted: m });
 }
 await wanzofc.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 } catch (error) {
 console.error(`Error: ${error}`);
 return m.reply(`Terjadi kesalahan: ${error.message}`);
 }
}
break

case 'songs':
case 'play': {
 if (!text) {
 return m.reply(`Contoh: ${prefix} aku yang tersakiti`)
 }
 try {
 wanzofc.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
 const yts = require('yt-search')
const nyoba = await yts(text);
const { url, title, description, thumbnail, duration, ago, views, author } = nyoba.all[0];
 const body = `• Judul: ${title}\n` +
 `• Channel: ${author.name}\n` +
 `• Durasi: ${duration}\n` +
 `• Link: ${url}\n\nKlik *Video* tuk vidio\nKlik *Audio* tuk audio`
 const buttons = [
 {
 buttonId: `${prefix}ytmp4 ${url}`,
 buttonText: { displayText: 'Video' },
 type: 1
 },
 {
 buttonId: `${prefix}ytmp3 ${url}`,
 buttonText: { displayText: 'Audio' },
 type: 1
 }
 ]
 await wanzofc.sendMessage(m.chat, {
 image: { url: thumbnail },
 caption: body,
 footer: null,
 buttons: buttons,
 headerType: 1,
 viewOnce: true
 }, { quoted: m })
 } catch (err) {
 console.error(err)
 m.reply('Terjadi kesalahan: '+err)
 }
}
break

case 'ytmp3': {
 if (!text) return m.reply(`Silakan masuk kan link youtube nya, Contoh: ${prefix + command} https://youtube.com/watch?v=Xs0Lxif1u9E`);
 const url = text.trim();
 const format = 'mp3';
 const regex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/;
 if (!regex.test(url)) {
 return m.reply('link yang anda berikan tidak valid, silahkan masuk kan link yang benar.');
 }
 m.reply('✨ Tunggu sebentar');
 try {
 const headers = {
 "accept": "*/*",
 "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
 "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
 "sec-ch-ua-mobile": "?1",
 "sec-ch-ua-platform": "\"Android\"",
 "sec-fetch-dest": "empty",
 "sec-fetch-mode": "cors",
 "sec-fetch-site": "cross-site",
 "Referer": "https://id.ytmp3.mobi/",
 "Referrer-Policy": "strict-origin-when-cross-origin"
 }
const initial = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, {headers});
let format = 'mp4';
const init = await initial.json();
const id = url.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
let convertURL = init.convertURL + `&v=${id}&f=${format}&_=${Math.random()}`;
const converts = await fetch(convertURL, {headers});
const convert = await converts.json();
let info = {};
for (let i = 0; i < 3; i++ ){
 let j = await fetch(convert.progressURL, {headers});
 info = await j.json();
 console.log(info);
 if (info.progress == 3) break;
}
const result = {
 url: convert.downloadURL,
 title: info.title
}
await wanzofc.sendMessage(m.chat, {
 audio: { url: result.url },
 mimetype: 'audio/mp4'
 }, { quoted: m });
} catch {
 reply('aduh kak error nieh..')
}
}
break

case 'ytmp4': {
 if (!text) return m.reply(`Silakan masuk kan link youtube nya, Contoh: ${prefix + command} https://youtube.com/watch?v=Xs0Lxif1u9E`);
try {
 const url = text.trim();
const headers = {
 "accept": "*/*",
 "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
 "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
 "sec-ch-ua-mobile": "?1",
 "sec-ch-ua-platform": "\"Android\"",
 "sec-fetch-dest": "empty",
 "sec-fetch-mode": "cors",
 "sec-fetch-site": "cross-site",
 "Referer": "https://id.ytmp3.mobi/",
 "Referrer-Policy": "strict-origin-when-cross-origin"
 }
const initial = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, {headers});
let format = 'mp4';
const init = await initial.json();
const id = url.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
let convertURL = init.convertURL + `&v=${id}&f=${format}&_=${Math.random()}`;
const converts = await fetch(convertURL, {headers});
const convert = await converts.json();
let info = {};
for (let i = 0; i < 3; i++ ){
 let j = await fetch(convert.progressURL, {headers});
 info = await j.json();
 console.log(info);
 if (info.progress == 3) break;
}
const result = {
 url: convert.downloadURL,
 title: info.title
}
await wanzofc.sendMessage(m.chat, { video: { url: result.url } }, { quoted: m });
} catch {
 reply('aduh kak error nieh..')
}
}
break

case 'mediafire': {
 if (!text) return m.reply(`Dimana linknya?`);
async function mediafireDownloader(url) {
 const response = await fetch('https://r.jina.ai/' + url, {
 headers: { 'x-return-format': 'html' }
 })
 if (!response.ok) throw new Error("Gagal mengambil data dari MediaFire!")

 const textHtml = await response.text()
 const $ = cheerio.load(textHtml)
 const TimeMatch = $('div.DLExtraInfo-uploadLocation div.DLExtraInfo-sectionDetails')
 .text()
 .match(/This file was uploaded from (.*?) on (.*?) at (.*?)\n/)
 const fileSize = $('a#downloadButton').text().trim().split('\n')[0].trim()
 return {
 title: $('div.dl-btn-label').text().trim() || "Tidak diketahui",
 filename: $('div.dl-btn-label').attr('title') || "file",
 url: $('a#downloadButton').attr('href'),
 size: fileSize || "Tidak diketahui",
 from: TimeMatch?.[1] || "Tidak diketahui",
 date: TimeMatch?.[2] || "Tidak diketahui",
 time: TimeMatch?.[3] || "Tidak diketahui"
 }
}
 wanzofc.mediafire = wanzofc.mediafire || {}
 if (m.sender in wanzofc.mediafire) return reply( "❗ Masih ada proses yang belum selesai. Silakan tunggu.")
 wanzofc.mediafire[m.sender] = true
 await wanzofc.sendMessage(m.chat, { react: { text: "🌀", key: m.key } })
 try {
 let result = await mediafireDownloader(text)
 if (!result.url) return reply("❌ Gagal mendapatkan link unduhan.")
 let caption = `✅ *Berhasil mengunduh file dari MediaFire!*\n\n`
 + `📂 *Nama File:* ${result.filename}\n`
 + `📦 *Ukuran:* ${result.size}\n`
 + `📅 *Tanggal Unggah:* ${result.date}\n`
 + `⏰ *Waktu Unggah:* ${result.time}\n`
 + `🌍 *Diupload dari:* ${result.from}\n\n`
 + `🔗 *Link:* ${result.url}`
 await wanzofc.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
 await wanzofc.sendMessage(m.chat, {
 document: { url: result.url },
 mimetype: 'application/octet-stream',
 fileName: result.filename,
 caption: caption
 }, { quoted: m })
 } catch (error) {
 await wanzofc.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
 m.reply(`❌ *Gagal mengunduh file:* ${error.message}`)
 }
 delete wanzofc.mediafire[m.sender]
}
break

case 'ghstalk': case 'githubstalk':{
wanzofc.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
if (!q) return m.reply(`Example ${prefix+command} wanzofc`)
wanzofc.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
aj = await githubstalk.githubstalk(`${q}`)
wanzofc.sendMessage(m.chat, { image: { url : aj.profile_pic }, caption: 
`*/ Github Stalker \\*

Username : ${aj.username}
Nickname : ${aj.nickname}
Bio : ${aj.bio}
Id : ${aj.id}
Nodeid : ${aj.nodeId}
Url Profile : ${aj.profile_pic}
Url Github : ${aj.url}
Type : ${aj.type}
Admin : ${aj.admin}
Company : ${aj.company}
Blog : ${aj.blog}
Location : ${aj.location}
Email : ${aj.email}
Public Repo : ${aj.public_repo}
Public Gists : ${aj.public_gists}
Followers : ${aj.followers}
Following : ${aj.following}
Created At : ${aj.ceated_at}
Updated At : ${aj.updated_at}` }, { quoted: m } )
}
break

case 'ttaudio':
case 'tiktokaudio':{
if (!text) return m.reply( `Example : ${prefix + command} link`)
wanzofc.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});
const data = await fetchJson(`https://skizoasia.xyz/api/tiktok?apikey=nonogembul&url=${encodeURIComponent(text)}`)
const audionya = data.data.music_info.play
wanzofc.sendMessage(m.chat, { audio: { url: audionya }, mimetype: 'audio/mp4' }, { quoted: m })
}
break
case 'addcase': {

 if (!isOwner) return m.reply('lu sapa asu')

 if (!text) return m.reply('Mana case nya');
    const fs = require('fs');
const namaFile = './case.js';
const caseBaru = `${text}`;
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                m.reply('Case baru berhasil ditambahkan.');
            }
        });
    } else {
        reply('Tidak dapat menambahkan case dalam file.');
    }
});

}
break            
            case 'autoai': {
    if (!isOwner) return m.reply('Contoh: autoai on / autoai off');
    if (args[0] === 'on') {
        autoAIPrivate = true;
        m.reply('✅ AutoAI *pribadi* diaktifkan. Sekarang bot akan membalas semua pesan private.');
    } else if (args[0] === 'off') {
        autoAIPrivate = false;
        m.reply('❌ AutoAI pribadi dinonaktifkan.');
    }
}
break;

case 'autoaigrup': {
    if (!m.isGroup) return m.reply('Hanya bisa digunakan di grup.');
    if (!isOwner) return m.reply('Contoh: autoaigrup on / autoaigrup off');
    if (args[0] === 'on') {
        autoAIGroup[m.chat] = true;
        m.reply('✅ AutoAI grup diaktifkan.');
    } else if (args[0] === 'off') {
        delete autoAIGroup[m.chat];
        m.reply('❌ AutoAI grup dinonaktifkan.');
    }
}
break;

default:
const isAllowed = (!m.isGroup && autoAIPrivate) || (m.isGroup && autoAIGroup[m.chat]);
const now = Date.now();

if (isAllowed && budy && !m.key.fromMe) {
    if (lastAutoAI[sender] && now - lastAutoAI[sender] < 5000) return;
    lastAutoAI[sender] = now;

    try {
        const url = `https://api.only-awan.biz.id/api/ai/gpt3?prompt=kamu adalah wanzofc menggunakan huruf kecil semua dan emoji setiap pesan kamu, dan untuk donasi ketik topup dan ini untuk fitur fitur saya punya ────── [ owner menu ] ──────

stopspam

spamtag

self

public

────── [ download menu ] ─────

tiktok

mediafire

ytmp3

ytmp4

songs

snackvideo

────── [ stalking menu ] ─────

igstalk&content=${encodeURIComponent(budy)}&apikey=jcj6uqsC`;
        const res = await fetch(url);
        const json = await res.json();

        if (json?.data?.status && json?.data?.data) {
            await wanzofc.sendMessage(m.chat, { text: json.data.data }, { quoted: m });
        }
    } catch (err) {
        console.error('[AUTOAI ERROR]', err);
    }
}

if (budy.startsWith('=>')) {
if (!isCreator) return;
try {
let result = await eval(`(async () => { return ${budy.slice(3)} })()`);
await wanzofc.sendMessage(m.chat, { text: util.format(result) });
} catch (e) {
await wanzofc.sendMessage(m.chat, { text: String(e) });
}
}
if (budy.startsWith('>')) {
if (!isCreator) return;
try {
let result = await eval(`(async () => { return ${text} })()`);
await wanzofc.sendMessage(m.chat, { text: util.format(result) });
} catch (e) {
await wanzofc.sendMessage(m.chat, { text: String(e) });
}
}
if (budy.startsWith('$')) {
if (!isCreator) return;
exec(budy.slice(2), (err, stdout) => {
if (err) return wanzofc.sendMessage(m.chat, { text: `${err}` });
if (stdout) return wanzofc.sendMessage(m.chat, { text: stdout });
});
}
}
} catch (err) {
console.log(util.format(err));
}
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(`Update ${__filename}`);
    delete require.cache[file];
    require(file);
});