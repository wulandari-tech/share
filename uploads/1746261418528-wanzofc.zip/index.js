const { default: makeWASocket, DisconnectReason, makeInMemoryStore, jidDecode, proto, getContentType, useMultiFileAuthState, downloadContentFromMessage } = require("@fizzxydev/baileys-pro")
const pino = require('pino')
const { Boom } = require('@hapi/boom')
const readline = require("readline");
const fs = require('fs')
const punycode = require('punycode/');
const { exec } = require('child_process');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const PhoneNumber = require('awesome-phonenumber')
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
const question = (text) => { 
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); 
    return new Promise((resolve) => { rl.question(text, (answer) => { rl.close(); resolve(answer); }) }) 
};

async function startBotz() {
    const { state, saveCreds } = await useMultiFileAuthState("session")
    const wanzofc = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: false,
        auth: state,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        emitOwnEvents: true,
        fireInitQueries: true,
        generateHighQualityLinkPreview: true,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
    });

if (!wanzofc.authState.creds.registered) {
    console.log("\x1b[34mMasukkan Nomor Aktif\x1b[0m");

    rl.question("> ", async (phoneNumber) => {
        if (!phoneNumber.startsWith("62")) {
            console.log("\x1b[34mNomor harus dimulai dengan 62. Silakan coba lagi.\x1b[0m");
            rl.close();
            return;
        }

        try {
            let code = await wanzofc.requestPairingCode(phoneNumber);
            code = code?.match(/.{1,4}/g)?.join("-") || code;

            console.log(`Pairing Code: ${code}`);
            console.log("Silakan buka WhatsApp dan masukin kode di bagian 'Tautkan Perangkat'.");
        } catch (error) {
            console.error("Gagal mendapatkan pairing code:", error);
        } finally {
            rl.close();
        }
    });
}

    store.bind(wanzofc.ev)
    
wanzofc.ev.on('messages.upsert', async (chatUpdate) => {
    try {
        let mek = chatUpdate.messages[0];
        if (!mek.message) return;

        mek.message = mek.message.ephemeralMessage ? mek.message.ephemeralMessage.message : mek.message;
        if (mek.key && mek.key.remoteJid === 'status@broadcast') return;

        let from = mek.key.remoteJid;
        let m = smsg(wanzofc, mek, store);
        
        let chatType;
        if (from.endsWith('@g.us')) {
            chatType = '\x1b[34m[GRUP]\x1b[0m'; // Biru
        } else if (from.endsWith('@s.whatsapp.net')) {
            chatType = '\x1b[32m[PRIVATE CHAT]\x1b[0m'; // Hijau
        } else {
            chatType = '\x1b[33m[SALURAN]\x1b[0m'; // Kuning
        }

        console.log(`${chatType} Pesan Baru dari ${from}: \x1b[36m${m.text}\x1b[0m`);

        await new Promise(resolve => setTimeout(resolve, 0));
        require("./case")(wanzofc, m, chatUpdate, store);

    } catch (err) {
        console.error("\x1b[31m❌ Error di messages.upsert:\x1b[0m", err);
    }
});
wanzofc.ev.on("group-participants.update", async (update) => {
    try {
        const { id, participants, action } = update;
        const groupMetadata = await wanzofc.groupMetadata(id);
        const groupName = groupMetadata.subject;

        for (let participant of participants) {
            let ppUrl;
            try {
                ppUrl = await wanzofc.profilePictureUrl(participant, "image");
            } catch {
                ppUrl = "https://files.catbox.moe/116wxz.jpg"; // Foto default jika tidak ada
            }
            if (action === "add") {
                let welcomeText = `👋 Selamat datang @${participant.split("@")[0]} di grup *${groupName}*! 🎉\n\nSilakan perkenalkan diri dan ikuti aturan grup ya!`;
                let welcomeMessage = {
                    image: { url: ppUrl },
                    caption: welcomeText,
                    mentions: [participant],
                };
                await wanzofc.sendMessage(id, welcomeMessage);
            }
            if (action === "remove") {
                let farewellText = `👋 Selamat tinggal @${participant.split("@")[0]}! Semoga sukses di luar sana! 👋`;
                let farewellMessage = {
                    image: { url: ppUrl },
                    caption: farewellText,
                    mentions: [participant],
                };
                await wanzofc.sendMessage(id, farewellMessage);
            }
            if (action === "promote") {
                let promoteText = `🎉 Selamat! @${participant.split("@")[0]} sekarang adalah admin di grup *${groupName}*! 🚀`;

                await wanzofc.sendMessage(id, { text: promoteText, mentions: [participant] });
            }
            if (action === "demote") {
                let demoteText = `⚠️ @${participant.split("@")[0]} tidak lagi menjadi admin di grup *${groupName}*.`; 

                await wanzofc.sendMessage(id, { text: demoteText, mentions: [participant] });
            }
        }
    } catch (err) {
        console.error("Error handling auto greet & admin update:", err);
    }
});
    wanzofc.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server ? decode.user + '@' + decode.server : jid;
        } 
        return jid;
    }

    wanzofc.getName = async (jid, withoutContact = false) => {
        let id = wanzofc.decodeJid(jid);
        let v;
        if (id.endsWith("@g.us")) {
            v = store.contacts[id] || {};
            if (!(v.name || v.subject)) v = await wanzofc.groupMetadata(id) || {};
            return v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international');
        } else {
            v = store.contacts[id] || {};
            return v.name || v.verifiedName || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international');
        }
    }

    wanzofc.public = false;
wanzofc.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            let statusCode = lastDisconnect?.error ? new Boom(lastDisconnect.error)?.output?.statusCode : null;
            if ([DisconnectReason.badSession, DisconnectReason.connectionClosed, DisconnectReason.connectionLost, DisconnectReason.connectionReplaced, DisconnectReason.restartRequired, DisconnectReason.timedOut].includes(statusCode)) {
                console.log("🔄 Reconnecting bot...");
                startBotz();
            } else if (statusCode === DisconnectReason.loggedOut) {
                console.log("🚨 Bot Logout! Hapus sesi...");
                fs.rmSync('./session', { recursive: true, force: true });
                setTimeout(() => exec("node index.js"), 3000);
            } else {
                console.log(`❓ Unknown DisconnectReason: ${statusCode}`);
            }
        } else if (connection === 'open') {
            console.log('✅ Bot Terhubung');
        }
    });
    
    wanzofc.ev.on('creds.update', saveCreds);
wanzofc.autoSholatStatus = wanzofc.autoSholatStatus || {};

    setInterval(async () => {
    try {
        let now = new Date();
        let offset = 7 * 60 * 60 * 1000; // Offset 7 jam untuk WIB
        let localTime = new Date(now.getTime() + offset);
        let hours = localTime.getUTCHours();
        let minutes = localTime.getUTCMinutes();
        let timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;

        let jadwalSholat = {
            shubuh: '04:40',
            dzuhur: '12:06',
            ashar: '15:12',
            magrib: '18:13',
            isya: '19:23'
        };

        for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
            if (timeNow === waktu) {
                let caption = `
📢 *PENGINGAT WAKTU SHOLAT* 📢
╭──────────────╮
│ 🕌 *${sholat.toUpperCase()}* telah tiba!  
│ ✧ Waktu: *${waktu} WIB*
│ ✧ Zona: Jakarta
│ 
│ 🚿 Ambil wudhu dan laksanakan sholat.
╰──────────────╯
🤲 Semoga ibadahmu diterima oleh Allah SWT.`;

                // Load data Auto Sholat
                let autoSholatFile = "./database/autoSholat.json";
                wanzofc.autoSholatStatus = fs.existsSync(autoSholatFile) ? JSON.parse(fs.readFileSync(autoSholatFile, "utf-8")) : {};

                // Kirim ke semua grup yang mengaktifkan Auto Sholat
                let groups = await wanzofc.groupFetchAllParticipating();
                for (let groupId in groups) {
                    if (wanzofc.autoSholatStatus[groupId]?.status) {
                        await wanzofc.sendMessage(groupId, { text: caption });

                        // Kirim juga ke user yang mengaktifkan di chat pribadi
                        for (let user of wanzofc.autoSholatStatus[groupId].users || []) {
                            await wanzofc.sendMessage(user, { text: `📩 *Pengingat Sholat untukmu!* 🕌\n\n${caption}` });
                        }
                    }
                }
            }
        }
    } catch (err) {
        console.error("⚠ Error di pengingat sholat:", err);
    }
}, 60000); 
    return wanzofc;
}

startBotz();

function smsg(wanzofc, m, store) {
    if (!m) return m;
    let M = proto.WebMessageInfo;
    if (m.key) {
        m.id = m.key.id;
        m.chat = m.key.remoteJid;
        m.fromMe = m.key.fromMe;
        m.isGroup = m.chat.endsWith('@g.us');
        m.sender = wanzofc.decodeJid(m.fromMe ? wanzofc.user.id : (m.participant || m.key.participant || m.chat));
        if (m.isGroup) m.participant = wanzofc.decodeJid(m.key.participant) || '';
    }
    if (m.message) {
        m.mtype = getContentType(m.message);
        m.msg = m.message[m.mtype];
        m.body = m.message.conversation || m.msg.caption || m.msg.text || m.msg.contentText || "";
        
        let quoted = m.quoted = m.msg.contextInfo ? m.msg.contextInfo.quotedMessage : null;
        m.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
        if (m.quoted) {
            let type = getContentType(quoted);
            m.quoted = m.quoted[type];
            if (typeof m.quoted === 'string') m.quoted = { text: m.quoted };
            m.quoted.mtype = type;
            m.quoted.id = m.msg.contextInfo.stanzaId;
            m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat;
            m.quoted.sender = wanzofc.decodeJid(m.msg.contextInfo.participant);
            m.quoted.fromMe = m.quoted.sender === wanzofc.decodeJid(wanzofc.user.id);
        }
    }
    m.text = m.body;
    m.reply = (text, chatId = m.chat, options = {}) => wanzofc.sendMessage(chatId, { text: text, ...options }, { quoted: m });

    return m;
}

fs.watchFile(require.resolve(__filename), () => {
    fs.unwatchFile(require.resolve(__filename));
    console.log(`♻️ Update ${__filename}`);
    delete require.cache[require.resolve(__filename)];
    require(__filename);
});
